# smoking > 2026-04-13 5:35pm
https://universe.roboflow.com/database-m3leo/smoking-wdoa5

Provided by a Roboflow user
License: CC BY 4.0

